<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200">
      <div class="container mx-auto px-6 py-2">
          
          <!-- Search Form -->
          <div class="flex justify-between items-center mb-4">
              <form action="<?php echo e(route('admin.posts.index')); ?>" method="GET" class="flex">
                  <input type="text" name="search" placeholder="Search posts..." 
                         class="px-4 py-2 border rounded-md" value="<?php echo e(request('search')); ?>">
                  <button type="submit" class="bg-blue-500 text-white px-4 py-2 ml-2 rounded-md">
                      Search
                  </button>
              </form>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Post create')): ?>
                  <a href="<?php echo e(route('admin.posts.create')); ?>" class="bg-blue-500 text-white font-bold px-5 py-1 rounded focus:outline-none shadow hover:bg-blue-500 transition-colors ">
                      New post
                  </a>
              <?php endif; ?>
          </div>

          <!-- Posts Table -->
          <div class="bg-white shadow-md rounded my-6">
            <table class="text-left w-full border-collapse">
              <thead>
                <tr>
                  <th class="py-4 px-6 bg-grey-lightest font-bold text-sm text-grey-dark border-b border-grey-light">Title</th>
                  <th class="py-4 px-6 bg-grey-lightest font-bold text-sm text-grey-dark border-b border-grey-light w-2/12">Status</th>
                  <th class="py-4 px-6 bg-grey-lightest font-bold text-sm text-grey-dark border-b border-grey-light text-right w-2/12">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Post access')): ?>
                  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-grey-lighter">
                      <td class="py-4 px-6 border-b border-grey-light"><?php echo e($post->title); ?></td>
                      <td class="py-4 px-6 border-b border-grey-light">
                          <?php if($post->publish): ?>
                          <span class="text-white inline-flex items-center justify-center px-2 py-1 mr-2 text-xs font-bold leading-none text-white bg-green-500 rounded-full">Publish</span>
                          <?php else: ?>
                          <span class="inline-flex items-center justify-center px-2 py-1 mr-2 text-xs font-bold leading-none text-white bg-gray-500 rounded-full">Draft</span>
                          <?php endif; ?>
                      </td>
                      <td class="py-4 px-6 border-b border-grey-light text-right">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Post edit')): ?>
                        <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>" class="text-grey-lighter font-bold py-1 px-3 rounded text-xs bg-green hover:bg-green-dark text-blue-400">Edit</a>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Post delete')): ?>
                        <form action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="text-grey-lighter font-bold py-1 px-3 rounded text-xs bg-blue hover:bg-blue-dark text-red-400">Delete</button>
                        </form>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </tbody>
            </table>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Post access')): ?>
            <div class="text-right p-4 py-10">
              <?php echo e($posts->appends(['search' => request('search')])->links()); ?>

            </div>
            <?php endif; ?>
          </div>

      </div>
  </main>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\User_Management_System\resources\views/post/index.blade.php ENDPATH**/ ?>